<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<title>Page not found &#8211; Respet</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Respet &raquo; Feed" href="https://webthemesolution.com/respet/feed/" />
<link rel="alternate" type="application/rss+xml" title="Respet &raquo; Comments Feed" href="https://webthemesolution.com/respet/comments/feed/" />
<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>

<link rel='stylesheet' id='hfe-widgets-style-css' href='https://webthemesolution.com/respet/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.8.2' media='all' />
<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://webthemesolution.com/respet/wp-includes/css/dist/block-library/style.min.css?ver=7.1.4' media='all' />
<style id="classic-theme-styles-inline-css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}.wp-block-button{--wp--preset--dimension--25: 25%;--wp--preset--dimension--50: 50%;--wp--preset--dimension--75: 75%;--wp--preset--dimension--100: 100%;}:where(body) { margin: 0; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:root :where(.wp-block-icon svg){width: 24px;}
:where(.wp-block-gallery.is-layout-flex){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}:where(.wp-block-gallery.is-layout-grid){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}
:where(.wp-block-latest-posts.is-layout-flex){gap: 1.25em;}:where(.wp-block-latest-posts.is-layout-grid){gap: 1.25em;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-term-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-term-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
/*# sourceURL=global-styles-inline-css */
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://webthemesolution.com/respet/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.4' media='all' />
<link rel='stylesheet' id='hfe-style-css' href='https://webthemesolution.com/respet/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.8.2' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=4.0.5' media='all' />
<link rel='stylesheet' id='elementor-post-5-css' href='https://webthemesolution.com/respet/wp-content/uploads/elementor/css/post-5.css?ver=1791331722' media='all' />
<link rel='stylesheet' id='slick_css-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/css/slick.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='owl_css-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/css/owl.carousel.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='nivo_css-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/css/nivo-slider.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='flaticon-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/css/flaticon.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='section_style-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/css/section-style.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='responsive_css-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/css/section-resposive.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='elementor-post-176-css' href='https://webthemesolution.com/respet/wp-content/uploads/elementor/css/post-176.css?ver=1791331722' media='all' />
<link rel='stylesheet' id='noto-css' href='https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&#038;display=swap&#038;ver=1.1.1' media='all' />
<link rel='stylesheet' id='mulish-css' href='https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&#038;display=swap&#038;ver=1.1.1' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' media='all' />
<link rel='stylesheet' id='bootstrap_css-css' href='https://webthemesolution.com/respet/wp-content/themes/respet/assets/css/bootstrap.min.css?ver=4.6.2' media='all' />
<link rel='stylesheet' id='customization-css' href='https://webthemesolution.com/respet/wp-content/themes/respet/assets/css/theme-customization.css?ver=1.1.0' media='all' />
<link rel='stylesheet' id='header-css' href='https://webthemesolution.com/respet/wp-content/themes/respet/assets/css/header-main.css?ver=1.1.0' media='all' />
<link rel='stylesheet' id='post-style-css' href='https://webthemesolution.com/respet/wp-content/themes/respet/assets/css/post-type-style.css?ver=1.1.0' media='all' />
<link rel='stylesheet' id='theme-responsive-css' href='https://webthemesolution.com/respet/wp-content/themes/respet/assets/css/theme-responsive.css?ver=1.1.0' media='all' />
<link rel='stylesheet' id='webtheme-style-css' href='https://webthemesolution.com/respet/wp-content/themes/respet/style.css?ver=5.0.0' media='all' />
<link rel='stylesheet' id='hfe-elementor-icons-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' media='all' />
<link rel='stylesheet' id='hfe-icons-list-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='hfe-social-icons-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-gf-local-roboto-css' href='https://webthemesolution.com/respet/wp-content/uploads/elementor/google-fonts/css/roboto.css?ver=1749478510' media='all' />
<link rel='stylesheet' id='elementor-gf-local-robotoslab-css' href='https://webthemesolution.com/respet/wp-content/uploads/elementor/google-fonts/css/robotoslab.css?ver=1749478513' media='all' />
<link rel='stylesheet' id='elementor-gf-local-mulish-css' href='https://webthemesolution.com/respet/wp-content/uploads/elementor/google-fonts/css/mulish.css?ver=1749478535' media='all' />
<link rel='stylesheet' id='elementor-gf-local-notoserif-css' href='https://webthemesolution.com/respet/wp-content/uploads/elementor/google-fonts/css/notoserif.css?ver=1749478531' media='all' />
<link rel='stylesheet' id='elementor-icons-restly-flaticon-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/include/flaticons/assets/css/flaticon.css?ver=1.0.0' media='all' />
<script id="jquery-core-js" src="https://webthemesolution.com/respet/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
<script id="jquery-migrate-js" src="https://webthemesolution.com/respet/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1"></script>
<script id="jquery-js-after">
!function($){"use strict";$(document).ready(function(){$(this).scrollTop()>100&&$(".hfe-scroll-to-top-wrap").removeClass("hfe-scroll-to-top-hide"),$(window).scroll(function(){$(this).scrollTop()<100?$(".hfe-scroll-to-top-wrap").fadeOut(300):$(".hfe-scroll-to-top-wrap").fadeIn(300)}),$(".hfe-scroll-to-top-wrap").on("click",function(){$("html, body").animate({scrollTop:0},300);return!1})})}(jQuery);
!function($){'use strict';$(document).ready(function(){var bar=$('.hfe-reading-progress-bar');if(!bar.length)return;$(window).on('scroll',function(){var s=$(window).scrollTop(),d=$(document).height()-$(window).height(),p=d? s/d*100:0;bar.css('width',p+'%')});});}(jQuery);
//# sourceURL=jquery-js-after
</script>
<link rel="https://api.w.org/" href="https://webthemesolution.com/respet/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://webthemesolution.com/respet/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 7.1.4" />
<meta name="generator" content="Redux 4.5.10" /><meta name="generator" content="Elementor 4.0.5; features: e_font_icon_svg, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://webthemesolution.com/respet/wp-content/uploads/2024/12/fav-icon.png" sizes="32x32" />
<link rel="icon" href="https://webthemesolution.com/respet/wp-content/uploads/2024/12/fav-icon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://webthemesolution.com/respet/wp-content/uploads/2024/12/fav-icon.png" />
<meta name="msapplication-TileImage" content="https://webthemesolution.com/respet/wp-content/uploads/2024/12/fav-icon.png" />
<style id="respet_opt-dynamic-css" title="dynamic-css" class="redux-options-output">.theme-breadcumb-section{background-repeat:no-repeat;background-attachment:scroll;background-position:center center;background-image:url('https://webthemesolution.com/respet/wp-content/uploads/2024/12/bredcrumb-img.jpg');background-size:cover;}</style></head>
<body class="error404 wp-custom-logo wp-theme-respet ehf-footer ehf-template-respet ehf-stylesheet-respet hfeed elementor-default elementor-kit-5">
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary">Skip to content</a>
	<header class="theme-main-header">
			<!--  Main Header start here   -->	
									<div class="theme-main-menu ">
				<div class="container">
					<div class="manu-wrapper">

						<div class="site-branding">
							
								<a href="https://webthemesolution.com/respet/" class="custom-logo-link"><img src="https://webthemesolution.com/respet/wp-content/uploads/2024/12/Logo.png" alt=""></a>

														</div>
						<nav id="site-navigation" class="main-navigation">
							<div class="menu-toggle"><i class="fa fa-bars"></i></div>
							<div class="header-nav">
							<div class="menu-main-menu-container"><ul id="primary-menu" class="menu-ul"><li id="menu-item-257" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-257"><a href="https://webthemesolution.com/respet/">Home</a></li>
<li id="menu-item-258" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-258"><a href="https://webthemesolution.com/respet/#about">About</a></li>
<li id="menu-item-259" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-259"><a href="https://webthemesolution.com/respet/#service">Service</a></li>
<li id="menu-item-260" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-260"><a href="https://webthemesolution.com/respet/#skill">Skills</a></li>
<li id="menu-item-261" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-261"><a href="https://webthemesolution.com/respet/#resume">Resume</a></li>
<li id="menu-item-264" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-264"><a href="https://webthemesolution.com/respet/#portfolio">Portfolio</a></li>
<li id="menu-item-262" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-262"><a href="https://webthemesolution.com/respet/#blog">Blog</a></li>
<li id="menu-item-263" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-263"><a href="https://webthemesolution.com/respet/#contact">Contact</a></li>
</ul></div>														</div>
						</nav>	
					</div>
				</div>
			</div>
				<!--  Main Header end here   -->
<!-- Top Header start here   -->
					
	<!-- go to top start -->
    <div class="go-to-top">
        <span class="go-top">
            Go To Top
            <i aria-hidden="true" class="flaticon flaticon-right-arrow"></i>
        </span>
    </div>
    <!-- go to top end -->
			
	</header>
	<div class="theme-breadcumb-section">
		<div class="container">
			<div class="theme-text-content">
				<h2>Page not found</h2>
				<ul><li><a href="https://webthemesolution.com/respet/">Home</a></li><li><i class="fa fa-angle-right"></i></li><li>404</li></ul>			</div>
		</div>
	</div>
	<div class="error-section">
		<div class="container">
			<div class="erroe-content">
				<div class="error-main-title">
					<h3>404 / Error Page</h3>
				</div>
				<div class="error-title-content">
											<h3>404 Oops! Your search page does not exist.</h3>
									</div>

				<div class="error-page-description">
					<p>You should try again with other keyword.</p>
				</div>
			</div>
		</div>
	</div>

		<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="176" class="elementor elementor-176">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-c10897f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c10897f" data-element_type="section" data-e-type="section" id="footer" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d0d95e4" data-id="d0d95e4" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-362e40f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="362e40f" data-element_type="section" data-e-type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-f110253" data-id="f110253" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-03af32b elementor-widget elementor-widget-image" data-id="03af32b" data-element_type="widget" data-e-type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img width="204" height="58" src="https://webthemesolution.com/respet/wp-content/uploads/2024/12/footer-logo.png" class="attachment-large size-large wp-image-178" alt="" />															</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-e9a16ed elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e9a16ed" data-element_type="section" data-e-type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7c805a4" data-id="7c805a4" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4e0f053 e-grid-align-left elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="4e0f053" data-element_type="widget" data-e-type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
							<div class="elementor-social-icons-wrapper elementor-grid" role="list">
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-flaticon-facebook-4 elementor-repeater-item-c436efe" href="#">
						<span class="elementor-screen-only">Flaticon-facebook-4</span>
						<i aria-hidden="true" class="flaticon flaticon-facebook-4"></i>					</a>
				</span>
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-flaticon-pinterest-1 elementor-repeater-item-187ced2" href="#">
						<span class="elementor-screen-only">Flaticon-pinterest-1</span>
						<i aria-hidden="true" class="flaticon flaticon-pinterest-1"></i>					</a>
				</span>
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-flaticon-vimeo elementor-repeater-item-aa6f13d" href="#">
						<span class="elementor-screen-only">Flaticon-vimeo</span>
						<i aria-hidden="true" class="flaticon flaticon-vimeo"></i>					</a>
				</span>
					</div>
						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d75b608" data-id="d75b608" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-79f9bd3 elementor-widget elementor-widget-text-editor" data-id="79f9bd3" data-element_type="widget" data-e-type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>Lawyer and Lay is optimizing standing manufactured produc and installation synergy. predo why professional business and porme and Consulting is optimi</p>								</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-21c65fc" data-id="21c65fc" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f574b57 elementor-widget elementor-widget-heading" data-id="f574b57" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Contact Info</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-9f9acb8 elementor-widget elementor-widget-text-editor" data-id="9f9acb8" data-element_type="widget" data-e-type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>121 King Street Melbourne, 3000/Australia</p>								</div>
				</div>
				<div class="elementor-element elementor-element-1b283d0 elementor-widget elementor-widget-text-editor" data-id="1b283d0" data-element_type="widget" data-e-type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>Australia 121 King Street Melbourne,3000</p>								</div>
				</div>
				<div class="elementor-element elementor-element-2a9cf06 elementor-widget elementor-widget-text-editor" data-id="2a9cf06" data-element_type="widget" data-e-type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>101 King Street Melbourne.</p>								</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7fa98a6" data-id="7fa98a6" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d1fc61e elementor-widget elementor-widget-heading" data-id="d1fc61e" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Click &amp; Read</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-7d27fd2 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="7d27fd2" data-element_type="widget" data-e-type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="#home">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-next"></i>						</span>
										<span class="elementor-icon-list-text">Home</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#about">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-next"></i>						</span>
										<span class="elementor-icon-list-text">About</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#service">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-next"></i>						</span>
										<span class="elementor-icon-list-text">Service</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#blog">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-next"></i>						</span>
										<span class="elementor-icon-list-text">Blog</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#contact">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-next"></i>						</span>
										<span class="elementor-icon-list-text">Contact</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6c9d830" data-id="6c9d830" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-aa863ae elementor-widget elementor-widget-heading" data-id="aa863ae" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Quick Contact</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-105b9b1 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="105b9b1" data-element_type="widget" data-e-type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-call-answer"></i>						</span>
										<span class="elementor-icon-list-text">+236-541-7890</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-call-answer"></i>						</span>
										<span class="elementor-icon-list-text">+528-586-9360</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-email"></i>						</span>
										<span class="elementor-icon-list-text">example@gmail.com</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-placeholder"></i>						</span>
										<span class="elementor-icon-list-text">Locka, #8 road Australia</span>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#contact">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="flaticon flaticon-contract"></i>						</span>
										<span class="elementor-icon-list-text">Contact with info details</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-e59e36c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e59e36c" data-element_type="section" data-e-type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9096f2c" data-id="9096f2c" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2f5f508 elementor-widget elementor-widget-image" data-id="2f5f508" data-element_type="widget" data-e-type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img width="204" height="58" src="https://webthemesolution.com/respet/wp-content/uploads/2024/12/Logo.png" class="attachment-large size-large wp-image-44" alt="" />															</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div>		</footer>
	</div><!-- #page -->
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/respet/*"},{"not":{"href_matches":["/respet/wp-*.php","/respet/wp-admin/*","/respet/wp-content/uploads/*","/respet/wp-content/*","/respet/wp-content/plugins/*","/respet/wp-content/themes/respet/*","/respet/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<link rel='stylesheet' id='widget-image-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/widget-image.min.css?ver=4.0.5' media='all' />
<link rel='stylesheet' id='widget-social-icons-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=4.0.5' media='all' />
<link rel='stylesheet' id='e-apple-webkit-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/conditionals/apple-webkit.min.css?ver=4.0.5' media='all' />
<link rel='stylesheet' id='widget-heading-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=4.0.5' media='all' />
<link rel='stylesheet' id='widget-icon-list-css' href='https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=4.0.5' media='all' />
<script id="wp-hooks-js" src="https://webthemesolution.com/respet/wp-includes/js/dist/hooks.min.js?ver=f0f188028580e8dc1255"></script>
<script id="wp-i18n-js" src="https://webthemesolution.com/respet/wp-includes/js/dist/i18n.min.js?ver=1dfe7db3940c23ea9216"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="swv-js" src="https://webthemesolution.com/respet/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.4"></script>
<script id="contact-form-7-js-before">
var wpcf7 = {
    "api": {
        "root": "https:\/\/webthemesolution.com\/respet\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
//# sourceURL=contact-form-7-js-before
</script>
<script id="contact-form-7-js" src="https://webthemesolution.com/respet/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.4"></script>
<script id="tabscript-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/js/tabscript.js?ver=1.1"></script>
<script id="slick_js-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/js/slick.min.js?ver=1.1"></script>
<script id="owl_js-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/js/owl.carousel.min.js?ver=1.1"></script>
<script id="counter_js-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/js/jquery.counterup.min.js?ver=1.1"></script>
<script id="counter__waypoints-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/js/waypoints.min.js?ver=1.1"></script>
<script id="nivo_js-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor-webtheme-widget/assets/js/jquery.nivo.slider.pack.js?ver=1.1"></script>
<script id="bootstrap-js" src="https://webthemesolution.com/respet/wp-content/themes/respet/assets/js/bootstrap.min.js?ver=5.0.0"></script>
<script id="theme-script-js" src="https://webthemesolution.com/respet/wp-content/themes/respet/assets/js/theme-script.js?ver=5.0.0"></script>
<script id="imageload_js-js" src="https://webthemesolution.com/respet/wp-content/themes/respet/assets/js/imagesloaded.pkgd.min.js?ver=5.0.0"></script>
<script id="isotope-js" src="https://webthemesolution.com/respet/wp-content/themes/respet/assets/js/isotope.pkgd.min.js?ver=5.0.0"></script>
<script id="animation_js-js" src="https://webthemesolution.com/respet/wp-content/themes/respet/assets/js/jquery.animatedheadline.min.js?ver=5.0.0"></script>
<script id="webtheme-theme-js" src="https://webthemesolution.com/respet/wp-content/themes/respet/assets/js/theme-customize.js?ver=5.0.0"></script>
<script id="elementor-webpack-runtime-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=4.0.5"></script>
<script id="elementor-frontend-modules-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=4.0.5"></script>
<script id="jquery-ui-core-js-before">
jQuery.uiBackCompat = true;
//# sourceURL=jquery-ui-core-js-before
</script>
<script id="jquery-ui-core-js" src="https://webthemesolution.com/respet/wp-includes/js/jquery/ui/core.min.js?ver=1.14.2"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"4.0.5","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"global_classes_should_enforce_capabilities":true,"e_variables":true,"e_opt_in_v4_page":true,"e_components":true,"e_interactions":true,"e_widget_creation":true,"import-export-customization":true},"urls":{"assets":"https:\/\/webthemesolution.com\/respet\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/webthemesolution.com\/respet\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/webthemesolution.com\/respet\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"01bc36cd90","atomicFormsSendForm":"44ec48b414"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found &#8211; Respet","excerpt":""}};
//# sourceURL=elementor-frontend-js-before
</script>
<script id="elementor-frontend-js" src="https://webthemesolution.com/respet/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=4.0.5"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://webthemesolution.com/respet/wp-includes/js/wp-emoji-release.min.js?ver=7.1.4"}}
</script>
<script type="module">
/*! This file is auto-generated */
var e="script#wp-emoji-settings",t=document.querySelector(e);if(!(t instanceof HTMLScriptElement))throw new Error("Element missing: "+e);const r=JSON.parse(t.text),s=(window._wpemojiSettings=r,"wpEmojiSettingsSupports"),o=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(s,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const r=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===r[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,r){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!r(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,r){let a;const s=(a="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),o=(s.textBaseline="top",s.font="600 32px Arial",{});return e.forEach(e=>{o[e]=t(s,e,n,r)}),o}function a(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}r.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(s));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(o),u.toString(),c.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"});const a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=e=>{i(n=e.data),a.terminate(),t(n)})}catch(e){}i(n=f(o,u,c,p))}t(n)}).then(e=>{for(const n in e)r.supports[n]=e[n],r.supports.everything=r.supports.everything&&r.supports[n],"flag"!==n&&(r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&r.supports[n]);var t;r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&!r.supports.flag,r.supports.everything||((t=r.source||{}).concatemoji?a(t.concatemoji):t.wpemoji&&t.twemoji&&(a(t.twemoji),a(t.wpemoji)))});
//# sourceURL=https://webthemesolution.com/respet/wp-includes/js/wp-emoji-loader.min.js
</script>
</body>
</html> 


<!-- Page cached by LiteSpeed Cache 7.8.0.1 on 2026-11-09 16:17:57 -->